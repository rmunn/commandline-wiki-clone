namespace FSharp
open System

open System.Reflection


[<assembly: System.Reflection.AssemblyCompanyAttribute("Company XYZ")>]
[<assembly: System.Reflection.AssemblyConfigurationAttribute("Debug")>]
[<assembly: System.Reflection.AssemblyCopyrightAttribute("Copyright (c) 2019 ")>]
[<assembly: System.Reflection.AssemblyFileVersionAttribute("1.2.3.0")>]
[<assembly: System.Reflection.AssemblyInformationalVersionAttribute("1.2.3-beta")>]
[<assembly: System.Reflection.AssemblyProductAttribute("Demo.FS")>]
[<assembly: System.Reflection.AssemblyTitleAttribute("Parser Demo")>]
[<assembly: System.Reflection.AssemblyVersionAttribute("1.2.3.0")>]
do()
