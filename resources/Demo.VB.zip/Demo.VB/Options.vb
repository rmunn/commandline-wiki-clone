﻿Imports CommandLine

'Module Program

Class Options
        <[Option]("r"c, "read", Required:=True, HelpText:="Input files to be processed.")>
        Public Property InputFiles As IEnumerable(Of String)
        <[Option]([Default]:=False, HelpText:="Prints all messages to standard output.")>
        Public Property Verbose As Boolean
        <[Option]("stdin", [Default]:=False, HelpText:="Read from stdin")>
        Public Property stdin As Boolean
        <Value(0, MetaName:="offset", HelpText:="File offset.")>
        Public Property Offset As Long?
    End Class

'End Module
